PYTHONIOENCODING=utf-8 python ./run_similarity.py
