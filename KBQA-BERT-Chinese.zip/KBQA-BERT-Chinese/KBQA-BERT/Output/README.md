# KBQA-BERT
基于知识图谱的问答系统，BERT做命名实体识别和句子相似度，分为online和outline模式
